function sayHello(name: string): void {
    console.log(`Hello ${name}!`);
  }
  
  sayHello('Dave');